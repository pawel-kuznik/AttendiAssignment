﻿
using AttendiRestAPI.DataModel;
using AttendiRestAPI.JSONConverters;
using Microsoft.AspNetCore.Mvc;

namespace AttendiRestAPI.Controllers
{
    /**
     *  This is a controller to manage a whole list of customers.
     */
    [ApiController]
    [Route("[controller]")]
    public class CustomersController
    {
        [HttpGet(Name = "Customers")]
        public CustomerJSON[] Get()
        {
            List<Customer> customers = DataRoot.Instance.GetCustomers();
            List<CustomerJSON> result = new List<CustomerJSON>();

            foreach (Customer customer in customers)
            {
                result.Add(new CustomerJSON(customer));
            }

            return result.ToArray();
        }
    }
}
