# REST API + Management UI

In this directory is a C# solution that runs a REST API (with a docker file to
create a docker image) and a separate directory that constain JS and HTML for
a management UI.

Admittely, the solution could be improved in both visuals and functionality,
but I was trying to keep with the limit of 4 hours for the whole assignment.